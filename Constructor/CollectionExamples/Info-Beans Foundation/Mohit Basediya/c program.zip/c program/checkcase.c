#include<stdio.h>
void main()
{
    char ch;
    printf("enter charater to check: \n");
    scanf("%c",&ch);
    printf("character is : %d",ch);
    if(ch<=95&& ch>=64)
    {
        printf("entered character is in upprer case.");
    }
    else
    printf("entered character is not in upper case");
}