#include<stdio.h>
void main()
{
    //convert feet to meter
    
    float feet,mtr;
    printf("enter feet to change into meter\n");
    scanf("%f",&feet);
    mtr=feet/3.37;
    printf("converted feet into meter: %.3f\n",mtr);
} 