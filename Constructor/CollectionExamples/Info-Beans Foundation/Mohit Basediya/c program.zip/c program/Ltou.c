#include<stdio.h>
void main()
{
    //lower case to upper case
    int ch;
    printf("enter a UPPER CASE character\n");
    scanf("%c",&ch);
    printf("character is : %c\n",ch);
    printf("ASCII value of lower case : %d\n",ch);
    printf(" lower case to upper case value is: %c\n",ch-32);
    printf("ASCII value of upper case: %d",ch-32);

}
