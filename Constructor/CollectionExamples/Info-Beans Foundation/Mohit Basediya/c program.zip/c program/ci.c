#include<stdio.h>
#include<math.h>
void main()
{
    int p,amt,t;
    float r,ci;
    printf("enter the value of p,t");
    scanf("%d%d",&p,&t);
    printf("enter r");
    scanf("%f",&r);
    amt=p*pow(1+r/100,t);
    ci=amt-p;
    printf("the compound interest is : %f",ci);
}