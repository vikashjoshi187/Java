#include<stdio.h>
void main()
{
    int a,b,c;
    printf("enter value of a,b and c to find greater no.\n");
    scanf("%d%d%d",&a,&b,&c);
    (a>b&&a>c)?printf("a is greater than b and c\n"):(b>c)?
    printf("b is greater"):printf("c is greater");

}