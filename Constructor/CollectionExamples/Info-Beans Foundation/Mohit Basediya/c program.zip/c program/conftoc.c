#include<stdio.h>
void main()
{
    float f,temp;
    printf("enter the value of f");
    scanf("%f",&f);
    temp= (f-32)*5/9;
    printf("tempreture converted into  celsius %.2f",temp);

}