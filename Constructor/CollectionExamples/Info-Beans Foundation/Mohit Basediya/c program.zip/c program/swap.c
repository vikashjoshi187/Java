#include<stdio.h>
void main()
{
    //swaping using 3rd var
    int a,b,c;
    printf("enter the value of a,b and c:");
    scanf("%d%d",&a,&b);
    c=a;
    a=b;
    b=c;

    printf("swaped value of a and b is %d\n %d\n",a,b);
}