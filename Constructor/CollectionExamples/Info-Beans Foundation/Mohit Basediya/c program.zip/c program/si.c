#include<stdio.h>
void main()
{
    int p,r,t,si;
    printf("enter the values of p,r,t\n");
    scanf("%d%d%d",&p,&r,&t);
    si=p*r*t/100;
    printf("simple interest: %d\n",si);
}