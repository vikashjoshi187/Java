#include<stdio.h>
void main()
{
    //convert mm to inches
    int mm;
    float inch;
    printf("enter mm to change into inches\n");
    scanf("%d",&mm);
    inch=mm*0.039;
    printf("converted mm into inch: %.3f\n",inch);
} 