#include<stdio.h>
void main()
{
    char ch;
    printf("enter a character to check\n");
    scanf("%c",&ch);
    printf("%d",ch);
    (ch>=97&&ch<=122)?printf("character is in lower case"):printf("character is in upper case");

}