#include<stdio.h>
void main()
{
    // Total marks and percenage
    int m1,m2,m3,m4,m5,total;
    float per;
    printf("enter the 5 subjects marks:\n ");
    scanf("%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5);
    printf("marks of m1,m2,m3,m4,m5 is\n %d\n%d\n%d\n%d\n%d\n",m1,m2,m3,m4,m5);
    total=m1+m2+m3+m4+m5;
    printf("total marks is :\n %d\n",total);
    per=total*100/500;
    printf("percent is : %f",per);


}
