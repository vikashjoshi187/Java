#include<stdio.h>
void main()
{
    // convert celsius to fehranite
    float c,tempf;
    printf("enter value of celsius c: ");
    scanf("%f",&c);
    tempf=(9/5)*c+32;
    printf("tempreture: %.3f",tempf);
}