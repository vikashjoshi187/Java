#include<stdio.h>
#include<math.h>
void main()
{
    int p,t,amt;
    float r,ci,si;
    printf("enter the value of p,t,r\n");
    scanf("%d%d%f",&p,&t,&r);
    (p>=500)?printf("ci is : %f",ci=((p*pow(1+r/100,t)-p))):
    printf("si is :%f",si=p*r*t/100);
}
