#include<stdio.h>
void main()
{
    //convert cm to inch
    int height,h;
    printf("enter hieght in inch");
    scanf("%d",&height);
    h=height*2.54;
    printf("converted height from inch to cm is: %d\n",h);
}