#include<stdio.h>
void main()
{
    //percenage check
    int m1,m2,m3,m4,m5;
    float per;
    printf("enter marks of 5 student\n");
    scanf("%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5);
    per=(m1+m2+m3+m4+m5)*100/500;

    printf("percentage is: %f\n",per);
    if(per>=75&&per<=100)
    {
        printf("percentage is lies between 75 to 100\n");
    }
    else
    printf("percent is not lies between 75 to 100");   
} 