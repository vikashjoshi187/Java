#include<stdio.h>
void main()
{
    // swaping using bitwise op
    int a,b;
    printf("enter the value of a and b");
    scanf("%d%d",&a,&b);
    a=a^b;
    b=a^b;
    a=a^b;
    printf("swaped value of a %d\n and b %d\n",a,b);
}