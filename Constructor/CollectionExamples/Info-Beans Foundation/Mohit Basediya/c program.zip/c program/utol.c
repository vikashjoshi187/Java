#include<stdio.h>
void main()
{
    //upper case to lower case
    char ch;
    printf("enter a upercase character\n:");
    scanf("%ch",&ch);
    printf("entered character is : %c\n",ch);
    printf("upper case to lower case %c\n",ch+32);
}