#include<stdio.h>
int main()
{
    // average of 5 no.s
    int a,b,c,d,e,avg;
    printf("enter the value of a,b,c,d,e\n");
    scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);

    avg=(a+b+c+d+e)/5;
    printf("average of 5 numbers is:%d",avg);
    
}