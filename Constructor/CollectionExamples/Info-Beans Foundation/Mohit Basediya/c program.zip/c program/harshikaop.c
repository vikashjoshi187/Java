#include<stdio.h>
int main()
{
    //arithmatic operators
int a=5,b=7,c;
printf("value of a and b: %d \n %d\n",a,b);
c=a+b;
printf("value of c: %d\n",c);
c=a-b;
printf("value of c: %d\n",c);
c=a/b;
printf("value of c: %d\n",c);
c=a*b;
printf("value of c: %d\n",c);
c=a%b;
printf("value of c: %d\n",c);

//asignment operator
c=a;
printf("value of assign c: %d\n",c);

//short hand operator
a+=b;
printf("value of a+= : %d\n",a);
a-=b;
printf("value of a-= : %d\n",a);
a*=b;
printf("value of a*= : %d\n",a);
a/=b;
printf("value of a/= : %d\n",a);
a%=b;
printf("value of a%%= : %d\n",a);

//conditional or ternary operator
c=(a==b?1:0);
printf("value of c : %d\n",c);
c=(a==b?printf("true\n"):printf("false\n"));

//relation and logicL
int x = 9>6 && 8<9;
printf("x : %d\n",x);
int z= 45!=10;
printf("value of z: %d\n",z);

//logical operator and ternary
printf("this is ternary op with relation and logical");
int p=4,q=3;
 (p>q||++q)?printf("p : %d\nq:  %d\n",p,q):printf("q: %d\n",q); 
 //bitwise operator

 int r=9&10;
printf("r(bw and operator) : %d\n",r);

 r=9|10;
printf("r(bw or operator) : %d\n",r);
r=9^10;
printf("r(bw xor operator) : %d\n",r);
r=4<<2;
printf("r(bw leftshift operator) : %d\n",r);
r=4>>2;
printf("r(bw rightshift operator) : %d\n",r);
r=~5;
printf("r(bw compliment operator) : %d\n",r);










return 0;

}