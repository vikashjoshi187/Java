#include<stdio.h>
void main()
{
    int num;
    printf("enter a number to check\n");
    scanf("%d",&num);
    (num/2==0)?printf("entered number is positive\n"):
    printf("entered number is negetive\n");


}