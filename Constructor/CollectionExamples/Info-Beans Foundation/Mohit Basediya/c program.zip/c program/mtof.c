#include<stdio.h>
void main()
{
    //convert meter to feet
    int mtr;
    float feet;
    printf("enter mtr to change into feet\n");
    scanf("%d",&mtr);
    feet=mtr*3.37;
    printf("converted meter into feet: %.3f\n",feet);
} 