#include<stdio.h>
void main ()
{
    int year;
    printf("enter the year : ");
    scanf("%d",&year);

    (year%4==0&&year%400==0||year%100!=0)?printf("year is leap year"):
    printf("year is not a leap year");
}
