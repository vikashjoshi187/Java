//example of c programming language
#include<stdio.h>

void main()
{
//printf("hello would \n");
 int a= printf("o\t")+printf("%d1\n");
printf("velue of a is: %d \n", a);
}