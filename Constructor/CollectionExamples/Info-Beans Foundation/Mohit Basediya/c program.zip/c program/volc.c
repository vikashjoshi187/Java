#include<stdio.h>
#include<math.h>
void main()
{
    // volume of cylinder
    float volc;
    float const pi=3.14;
    int r,h;
    printf("enter the value of r and h ");
    scanf("%d%d",&r,&h);
    volc=pi*(pow(r,2)*h);
    printf("volume of cylinder is : %f",volc);


}