#include<stdio.h>
#include<math.h>
void main()
{
    // area of tringle by herons formula
    int a,b,c,s;
    float area;
    printf("enter the value of a,b,c");
    scanf("%d%d%d",&a,&b,&c);
    s=(a+b+c)/2;
    printf("value of s is : %d",s);
    area=sqrt((s*(s-a)*(s-b)*(s-c)));
    printf("value of area is : %f",area);

}