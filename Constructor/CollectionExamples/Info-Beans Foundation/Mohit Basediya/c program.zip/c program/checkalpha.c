#include<stdio.h>
void main()
{
    //check whether the entered charecter is alphabet 
    char ch;
    printf("enter a charecter to check:");
    scanf("%c",&ch);
    printf("entered character ASCII value is :%d\n",ch);
    (ch<=90&&ch>=65)||(ch<=122&&ch>=97)?printf("entered character is alphabet\n")
    :printf("entered character is not a alphabet\n");
}
