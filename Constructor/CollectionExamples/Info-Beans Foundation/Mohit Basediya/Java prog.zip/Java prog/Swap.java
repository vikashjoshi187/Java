// program to swap two number using third
class Swap
{
    public static void main (String args[])
    {
        int a=5,b=6,c;
        System.out.println("value of a and b :\n"+a+"\n"+b);
        c=a;a=b;b=c;
        System.out.println("swapped value of a and b :\n"
        +a+"\n"+b);
    }
}
