// height from mm to inch
class Mmtoin
{
    public static void main (String args[])
    {
        double mm=5,in;
        System.out.println("height in millimeter : "+mm);
        in=mm/25.4;
        System.out.println("millimeter to inch : "+in);
    }
}