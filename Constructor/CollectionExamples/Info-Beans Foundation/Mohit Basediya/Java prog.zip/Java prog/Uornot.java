// program to chech entered character is alphabet not using conditional operator
class Uornot
{
    public static void main (String args[])
    {
    char ch = '1';
    System.out.println("charater : "+ch);
    String character = (ch>=65 && ch<=90)||(ch>=97&&ch<=122)?
    "characer is alphabet" : " not a alphabet ";
    System.out.println(character);
    }
}