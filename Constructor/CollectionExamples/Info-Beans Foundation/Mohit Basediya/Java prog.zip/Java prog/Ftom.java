// height foot to meter
class Ftom
{
    public static void main (String args[])
    {
        double f=70,m;
        System.out.println("height in foot : "+f);
        m=f/3.281;
        System.out.println("foot to meter : "+m);
    }
}