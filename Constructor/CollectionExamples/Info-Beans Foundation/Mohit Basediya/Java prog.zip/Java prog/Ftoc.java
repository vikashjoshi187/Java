// program for conversion of F to C
class Ftoc
{
    public static void main (String args[])
    {
        double c,f=50;
        System.out.println("value of F : "+f);
        c = (f-32)*5/9;
        System.out.println("conversion from f to c : "
        +c);

    }
}
