// Simple Interest
class Simpleinterest
{
    public static void main (String args[])
    {
        int p=500,t=3;
        double r=2.5,si;
        System.out.println("value of p : "+p);
        System.out.println("value of a : "+t);
        System.out.println("value of a : "+r);
        si=(p*r*t)/100;
        System.out.println("simple interest : "+si);
        
    }
}
