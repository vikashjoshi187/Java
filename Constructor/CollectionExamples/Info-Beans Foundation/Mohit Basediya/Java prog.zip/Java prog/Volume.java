// Program to find volume of cylinder
class Volume
{
    public static void main (String args[])
    {
        double r=10,h=20,pie=3.14,vol;
        System.out.println("value of r,h,pie : "+r+"\n"
        +h+"\n"+pie);
        vol=Math.pow(r,2)*h*pie;
        System.out.println("volume of cylinder : "+vol);
    }
}