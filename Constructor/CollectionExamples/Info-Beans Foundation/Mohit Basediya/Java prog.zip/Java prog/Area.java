// program for area of triangle
class Area
{
    public static void main (String args[])
    {
        int a=30,b=55,c=77;
        float s;
        double area;
        System.out.println
        ("value of a,b,c : \n"+a+"\n"+b+"\n"+c);
        s=(a+b+c)/2;
        System.out.println("Semiperimeter of Triangle : "+s);
        area = Math.sqrt(s*(s-a)*(s-b)*(s-c));
        System.out.println("Area of Triangle : "+area);
    }
}