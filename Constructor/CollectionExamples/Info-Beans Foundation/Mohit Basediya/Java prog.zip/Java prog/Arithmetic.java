// program for all arithmetic operations
class Arithmetic
{
    public static void main(String args[])
    {
        int a=20,b=10,c,d,e,f,g;
        System.out.println("value of a and b : "+a+"\n"+b);
        c=a+b;d=a-b;e=a*b;f=a/b;g=a%b;
        System.out.println("Addition : "+c);
        System.out.println("Substraction : "+d);
        System.out.println("Multiplication : "+e);
        System.out.println("Division: "+f);
        System.out.println("Modulus : "+g);
    }
}
