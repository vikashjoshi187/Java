// program to find uppercase or not and change in lowercasw
class Uornot1
{
    public static void main (String args[])
    {
    char ch = 'A';
    System.out.println("charater : "+ch);
    String character = (ch>=65 && ch<=90)?
    "Uppercase"+" "+"& conversion in lowercase is "+" "+(char)(ch+32):
    "character is in lowercase";
    System.out.println(character);
    }
}
