// program to find lowercase or not and change in uppercase
class Lornot1
{
    public static void main (String args[])
    {
    char ch = 'a';
    System.out.println("charater : "+ch);
    String character = (ch>=97 && ch<=122)?
    "Lowercase"+" "+"& conversion in Uppercase : "+" "+(char)(ch-32):
    "character is in uppercase";
    System.out.println(character);
    }
}