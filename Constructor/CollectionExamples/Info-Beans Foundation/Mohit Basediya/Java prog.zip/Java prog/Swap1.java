// program to swap two variable 
class Swap1
{
    public static void main (String args[])
    {
        int a=5,b=6;
        System.out.println("value of a and b : \n"+a+"\n"+b);
        a=a+b;b=a-b;a=a-b;
        System.out.println("Swapped value of a and b : \n"
        +a+"\n"+b);
    }
}