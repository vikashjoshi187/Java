// height from meter to foot
class Mtof
{
    public static void main (String args[])
    {
        double m=1.7,f;
        System.out.println("height in meter : "+m);
        f=m*3.281;
        System.out.println("meter to foot : "+f);
    }
}
