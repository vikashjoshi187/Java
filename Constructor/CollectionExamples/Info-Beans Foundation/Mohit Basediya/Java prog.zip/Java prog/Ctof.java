// program for conversion of c to f 
class Ctof
{
    public static void main (String args[])
    {
        double f,c=10;
        System.out.println("value of c : "+c);
        f = 32+(c*9/5);
        System.out.println("conversion in f : "+f);
    }
}
