// program to convert uppercase to lowercase
class Utol
{
    public static void main (String args[])
    {
        char ch = 'Q';
        System.out.println("uppercase to lowercase : "
        +(char)(ch+32));
    }
}