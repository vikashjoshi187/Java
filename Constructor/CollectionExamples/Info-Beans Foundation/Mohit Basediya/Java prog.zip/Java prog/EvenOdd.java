// program to find even or odd
class EvenOdd
{
    public static void main (String args[])
    {
    int num = 1;
    String num1 = (num%2==0)?"number is even":"number is odd";
    System.out.println(num1);
    }
}