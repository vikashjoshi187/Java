class Equalornot
{
    public static void main (String args[])
    {
        int a=9,b=9;
        String num = (a==b)?"numbers are equal":(a>b)?"a is greater":"b is greater";
        System.out.println(num);
    }
}