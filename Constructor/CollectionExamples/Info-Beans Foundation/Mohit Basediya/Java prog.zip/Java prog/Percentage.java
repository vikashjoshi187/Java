// program to find total & percentage of 5 subject
class percentage
{
    public static void main (String args[])
    {
        int m1=90,m2=90,m3=90,m4=87,m5=87;
        double total;
        System.out.println("value of m1: "+m1);
        System.out.println("value of m2: "+m2);
        System.out.println("value of m3: "+m3);
        System.out.println("value of m4: "+m4);
        System.out.println("value of m5: "+m5);
        total=m1+m2+m3+m4+m5;
        System.out.println("total marks: "+total);
        double per = (total*100)/500;
        System.out.println("Percentage : "+per);
    }
}