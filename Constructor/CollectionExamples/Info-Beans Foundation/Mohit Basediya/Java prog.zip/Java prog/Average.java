// average
class Average
{
    public static void main (String args[])
    {
        int a=10,b=20,c=30,avg;
        System.out.println("value of a : "+a);
        System.out.println("value of b : "+b);
        System.out.println("value of c : "+c);
        avg=(a+b+c)/3;
        System.out.println("average : "+avg);
    }
}