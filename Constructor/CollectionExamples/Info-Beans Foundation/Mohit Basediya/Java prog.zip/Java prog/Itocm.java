// height from inch to cm
class Itocm
{
    public static void main (String args[])
    {
        double I=70,cm;
        System.out.println("height in inches : "+I);
        cm = I*2.54;
        System.out.println("inch to cm : "+cm);
    }
}