// program to convert lowercase to uppercase
class Ltou
{
    public static void main (String args[])
    {
        char ch = 'a';
        System.out.println("lowercase to uppercase : "
        +(char)(ch-32));
    }
}