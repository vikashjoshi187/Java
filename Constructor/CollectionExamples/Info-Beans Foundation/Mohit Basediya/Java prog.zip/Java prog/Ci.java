// program to find compound interest
class Ci 
{
    public static void main(String args[])
    {
        int p=500,t=3;
        double r=2.5,amt,ci;
        System.out.println("value of p,t and r : \n"
        +p+"\n"+t+"\n"+r);
        amt = p*Math.pow(1+r/100,t);
        System.out.println("Amount : "+amt);
        ci = amt-p;
        System.out.println("Compound Interest : "+ci);
    }
}