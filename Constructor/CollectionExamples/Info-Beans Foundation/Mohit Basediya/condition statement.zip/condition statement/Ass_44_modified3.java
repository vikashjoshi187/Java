import java.util.Scanner;
public class Ass_44_modified3 {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        System.out.println("\n******************** Wealcome to the Holland Tunnel toll Services******************\n");

        System.out.println("Please choose the Vehicle type (enter integer from 1 to 10) :\n\n1 -> Vehicles with two axless and single rear wheel\n2 -> Vehicles  with two axless and dual rear wheels\n3 -> Vehicles with three axless\n4 -> vehicle with four axless\n5 -> Vehicle with five axless\n6 -> Vehicles with atleast 6 axless\n7 -> Class 1 or 11 with trailer\n8 -> Two Axless buses and mini busses\n9 -> Three Axless buses and mini busses \n10 -> Motorcycles ");
        int v = sc.nextInt();
        
        if(v<1 || v>10){
            System.out.println("warning!!!\nYou choosed invalid Vehicle type.\nPlease try again\nThanks for visiting Holland Tunnel.");
            System.exit(1);
        }

        int axles = 0;
        if(v==6 || v==7){
            System.out.println("\nPlease enter the number of Axels (less then 10): ");
            axles = sc.nextInt();          
            if(v==7){
                if(axles<3 || axles>10){
                    System.out.println("Warning!! \nIn this type of vehicles the number of axles is must be in range of 3 to 10 axles.\nPlease try again\nThanks for visiting Holland Tunnel");
                    System.exit(1);
                }
            }
            else if(v==6){
                if(axles<6 || axles>10){
                    System.out.println("Warning!! in this type of vehicles the number of axles is must be in range of 6 to 10 axles.\nPlease try again\nThanks for visiting Holland Tunnel.");
                    System.exit(1);
                }
            }
        }
        
        System.out.println("\nPlease enter your Payment method (enter 1 or 2) : \n1 -> EZ pass\n2 -> Cash ");
        int p = sc.nextInt();

        if(p==1 || p==2){                
            if(p==1){
                System.out.println("Your Payment Method is EZ pass.");

                System.out.println("\nPlease choose the Day (enter integer from 1 to 7) :\n1 -> Monday\n2 -> Tuesday\n3 -> Wednesday\n4 -> Thursday\n5 -> Friday\n6 -> Saturday\n7 -> Sunday");
                int day = sc.nextInt();

                if(day<1 || day>7){
                    System.out.println("warning!!!\nYou choosed invalid Option.\nPlease try again\nThanks for visiting Holland Tunnel.");
                    System.exit(1);
                }

                System.out.println("\nPlease enter the Time (hh.mm) (24 hour format)(00.00 to 23.59): ");
                float time = sc.nextFloat();
                if(time==24){time=0;}
                if(time>23.59f || time<0.0f){
                    System.out.println("warning!!!\nYou entered invalid time.\nPlease try again\nThanks for visiting Holland Tunnel.");
                    System.exit(1);
                }
                
                int peek=0;   //Initializing off peek hours              
                if (day>=1 && day<=5){//calculating peek hours
                    if(((int)time>=6 && (int)time<=9) || ((int)time>=16 && (int)time<=19)){
                        peek = 1;//peek hour
                    }
                }
                else if(day==6 || day==7){//calculating peek hours
                    if((int)time>=11 && (int)time<=20){
                        peek = 1;//peek hour
                    }
                }
                        
                int truckOvernight = 0;//calculating truck overnight hours
                if(v>=2 && v<=6){
                    if(day>=1 && day<=3){
                        if(((int)time>=22 && (int)time<=23) || ((int)time>=0 && (int)time<=5)){
                            truckOvernight =1;//overnight
                        }
                    }
                    else if(day==7){
                        if((int)time>=22 && (int)time<=23){
                            truckOvernight = 1;//overnight
                        }
                    }
                    else if(day==4){
                        if((int)time>=0 && (int)time<=5){
                            truckOvernight = 1;//overnight
                        }
                    }
                }
                
                if(peek==1){//displaying peek time
                    System.out.println("\nYou are in Peek hour.\n");
                }
                else if(truckOvernight==1){//dispalying overnight time 
                    System.out.println("\nYou are in Truck in Overnight hours.\n");
                }
                else if(peek==0){//displaying off peek times
                    System.out.println("\nYou are in Off peek hour.\n");
                }
                        
                if(v==1){
                    if(peek==0){
                        System.out.println("The final Amount for pay is $11.75\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else if(peek==1){
                        System.out.println("The final Amount for pay is $13.75\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                }
                else if(v==2){
                    if(peek==1){
                        System.out.println("The final Amount for pay is $38.\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else if(truckOvernight==1){
                        System.out.println("The final Amount for pay is $33.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else if(peek==0){
                        System.out.println("The final Amount for pay is $36.\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                }
                else if(v==3){
                    if(peek==1){
                        System.out.println("The final Amount for pay is $57.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else if(truckOvernight==1){
                        System.out.println("The final Amount for pay is $49.50\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else if(peek==0){
                        System.out.println("The final Amount for pay is $54.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                }
                else if(v==4){
                    if(peek==1){
                        System.out.println("The final Amount for pay is $76.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else if(truckOvernight==1){
                        System.out.println("The final Amount for pay is $66.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else if(peek==0){
                        System.out.println("The final Amount for pay is $72.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                }
                else if(v==5){
                    if(peek==1){
                        System.out.println("The final Amount for pay is $95.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else if(truckOvernight==1){
                        System.out.println("The final Amount for pay is $82.50\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else if(peek==0){
                        System.out.println("The final Amount for pay is $90.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                }
                else if(v==6){
                    if(peek==1){
                        if(axles>6){
                            float money = (114.0f)+((axles-6.0f)*19.0f);
                            System.out.println((axles-6.0f)+" axles are extra thats why $"+((axles-6.0f)*19.0f)+" Added extra in payment");
                            System.out.println("The final Amount for pay is $"+money+"\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                        }
                        else{
                            System.out.println("The final Amount for pay is $114.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                        }
                    }
                    else if(truckOvernight==1){
                        if(axles>6){
                            float money = (99.0f)+((axles-6.0f)*16.50f);
                            System.out.println((int)(axles-6.0f)+" axles are extra thats why $"+((axles-6.0f)*16.50f)+" Added extra in payment");
                            System.out.println("The final Amount for pay is $"+money+"\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                        }
                        else{
                            System.out.println("The final Amount for pay is $99.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                        }
                    }
                    else if(peek==0){
                        if(axles>6){
                            float money = (108.0f)+((axles-6.0f)*18.0f);
                            System.out.println((int)(axles-6.0f)+" axles are extra thats why $"+((axles-6.0f)*18.0f)+" Added extra in payment");
                            System.out.println("The final Amount for pay is $"+money+"\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                        }
                        else{
                            System.out.println("The final Amount for pay is $108.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                        }
                    }
                }
                else if(v==7){
                    if(peek==1){
                        if(axles>3){
                            float money = (24.25f)+((axles-3.0f)*10.50f);
                            System.out.println((int)(axles-3.0f)+" axles are extra thats why $"+((axles-3.0f)*10.50f)+" Added extra in payment");
                            System.out.println("The final Amount for pay is $"+money+"\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                        }
                        else{
                            System.out.println("The final Amount for pay is $24.25\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                        }
                    }
                    else if(peek==0){
                        if(axles>3){
                            float money = (22.25f)+((axles-3.0f)*10.50f);
                            System.out.println((int)(axles-3.0f)+" axles are extra thats why $"+((axles-3.0f)*10.50f)+" Added extra in payment");
                            System.out.println("The final final Amount for pay is $"+money+"\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                        }
                        else{
                            System.out.println("The final Amount for pay is $22.25\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                        }
                    }
                }
                else if(v==8 || v==9){
                    if(peek==0 || peek==1){
                        System.out.println("The final Amount for pay is $14.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                }
                else if(v==10){
                    if(peek==0){
                        System.out.println("The final Amount for pay is $10.75\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else if(peek==1){
                        System.out.println("The final Amount for pay is $12.75\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                }
            }
            else if(p==2){//start cash payment processing
                System.out.println("Your Payment Method Method is Cash.");
                
                if(v==1){
                    System.out.println("The final Amount for Pay is $16.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                }
                else if(v==2){
                    System.out.println("The final Amount for Pay is $44.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                }
                else if(v==3){
                    System.out.println("The final Amount for Pay is $66.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                }
                else if(v==4){
                    System.out.println("The final Amount for Pay is $88.0\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                }
                else if(v==5){
                    System.out.println("The final Amount for Pay is $110.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                }
                else if(v==6){
                    if(axles>6){
                        float money = (132.00f)+((axles-6.0f)*22.0f);
                        System.out.println((int)(axles-6.0f)+" axles are extra thats why $"+((axles-6.0f)*22.0f)+" Added extra in payment");
                        System.out.println("The final Amount for pay is $"+money+"\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else{
                        System.out.println("The final Amount for pay is $132.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                }
                else if(v==7){
                    if(axles>3){
                        float money = (34.0f)+((axles-3.0f)*18.0f);
                        System.out.println((int)(axles-3.0f)+" axles are extra thats why $"+((axles-3.0f)*18.0f)+" Added extra in payment");
                        System.out.println("The final final Amount for pay is $"+money+"\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                    else{
                        System.out.println("The final Amount for pay is $34.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                    }
                }
                else if(v==8){
                    System.out.println("The final Amount for Pay is $25.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                }
                else if(v==9){
                    System.out.println("The final Amount for Pay is $25.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                }
                else if(v==10){
                    System.out.println("The final Amount for Pay is $16.00\nThanks for Visiting Holland Tunnel.\nPlease Revisit again");
                }
            }
        }
        else{
            System.out.println("warning!!!\nYou entered invalid Payment method.\nPlease try again\nThanks for visiting Holland Tunnel.");
            System.exit(1);
        }
    }
}