// else if ladder statement
import java.util.Scanner;
class ladder1
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter a,b and c : ");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        if(a>b)
        {
            if (a>c)
              System.out.println(a+" is greater");
            else 
              System.out.println(c+" is greater");
        }
        else 
        {
            if(b>c)
              System.out.println(b+" is greater");
            else
              System.out.println(c+" is greater");
        }
    }
}