// WAP to Round Off 3 Digit Number.
import java.util.Scanner;
class Prog33
{
    public static void main(String args[])
    {
        int a,b,c;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any 3 Digit Number : ");
        a = sc.nextInt();
        if (a>99&&a<1000)
        {b = a%100;
         if(b>=0&&b<50) 
         {a = a-b;
         System.out.println("Round Off Value is : "+a);
         }
         else
         {
            c=100-b;
            a=a+c;
            System.out.println("Round Off Value is : "+a);
         }
        }
        else
        System.out.println("Not A 3 Digit Number");
    }
}
        /*b = a%10;
         if(b>0&&b<5) 
         {a = a-b;
         System.out.println("Round Off Value is : "+a);
         }
         else if (b>=5&&b<=9)
         {c = 10-b;
         a = a+c;
         System.out.println("Round Off Value is : "+a);
         }*/