/* Program to check whether entered character is in uppercase or not if yes ,then convert 
it into lowercase. */
import java.util.Scanner;
class Prog7
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter character : ");
        char ch = sc.next().charAt(0);
        if(ch>=65 && ch<=90)
         System.out.println(ch+" is uppercase & conversion in lowercase : "+(char)(ch+32));
        else
         System.out.println("character is not uppercase");      
    }
}