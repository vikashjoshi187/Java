// WAP to accept 4 digit number & find out greatest & smallest digit from it.
import java.util.Scanner;
class Prog36
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any Four Digits Number : ");
        int a = sc.nextInt();
        int a1,a2,a3,a4,s;
        if (a>999 && a<10000)
        {
            a1 = a/1000;
            System.out.println("First Digit  : "+a1);
            a2 = a%1000/100;
            System.out.println("Second Digit : "+a2);
            a3 = a%100/10;
            System.out.println("Third Digit  : "+a3);
            a4 = a%10;
            System.out.println("Fourth Digit : "+a4);
            
            if (a1>a2&&a1>a3&&a1>a4){
            System.out.println(a1+" is Greatest");}
            else if (a2>a3&&a2>a3){
            System.out.println(a2+" is Greatest");}
            else if (a3>a4){
            System.out.println(a3+" is Greatest");}
            else  {
            System.out.println(a4+" is Greatest");
            }

            if (a1<a2&&a1<a3&&a1<a4){
            System.out.println(a1+" is Smallest");}
            else if (a2<a3&&a2<a3){
            System.out.println(a2+" is Smallest");}
            else if (a3<a4){
            System.out.println(a3+" is Smallest");}
            else  {
            System.out.println(a4+" is Smallest");
            }
        }
        else
        {
            System.out.println("Not a 4 Digit Number");
        }
    }
}