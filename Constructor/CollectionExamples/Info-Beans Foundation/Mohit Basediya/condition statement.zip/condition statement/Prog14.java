/* Program to ckeck whether first number is divisible by second or not. */
import java.util.Scanner;
class Prog14
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a & b : ");
        int a = sc.nextInt();
        int b = sc.nextInt();
        if (a%b==0)
         System.out.println(a+" is divisible by "+b);
        else 
         System.out.println(a+" is not divisible by "+b);
    }
}   