/* A cashier has some amount of money (e.g. 4526). Write a program to calculate how many 
currency of RS.1000, Rs.500, Rs.100, Rs50, Rs.20, Rs10, Rs.5, Rs.2, Rs.1 required. */
import java.util.Scanner;
class Prog23
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Amount : ");
        int a = sc.nextInt();
          int n1 = a/1000;
          System.out.println("Number of notes of Rs.1000 : "+n1);
          int n2 = a%1000/500;
          System.out.println("Number of notes of Rs.500  : "+n2);
          int n10 = a%500/200;
          System.out.println("Number of notes of Rs.200  : "+n10);
          int n3 = a%500%200/100;
          System.out.println("Number of notes of Rs.100  : "+n3);
          int n4 = a%100/50;
          System.out.println("Number of notes of Rs.50   : "+n4);
          int n5 = a%50/20;
          System.out.println("Number of notes of Rs.20   : "+n5);
          int n6 = a%50%20/10;
          System.out.println("Number of notes of Rs.10   : "+n6);
          int n7 = a%10/5;
          System.out.println("Number of notes of Rs.5    : "+n7);
          int n8 = a%5/2;
          System.out.println("Number of notes of Rs.2    : "+n8);
          int n9 = a%5%2/1;
          System.out.println("Number of notes of Rs.1    : "+n9);
    }
}