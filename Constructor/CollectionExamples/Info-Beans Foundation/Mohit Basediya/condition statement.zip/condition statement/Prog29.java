/* Write a program to calculate gross salary & net salary. Accept the basic salary from
user, TA(Travel Allowance) i.e. 10% of basic salary,PF(Provident Fund) i.e. 7.8% of basic
salary, DA(Dearness Allowance) is 500, GS=BS+DA+TA & NS=GS-PF. */
import java.util.Scanner;
class Prog29
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter the Basic Salary : ");
        double s = sc.nextDouble();
        System.out.println("Enter TA Percent : ");
        double tap = sc.nextDouble();
        double ta = s*tap/100;
        System.out.println("Enter PF percent : ");
        double pfp = sc.nextDouble();
        double pf = s*pfp/100;
        System.out.println("Enter Dearness Allowance (DA)");
        double da = sc.nextDouble();
        System.out.println("Travel Allowance (TA) : "+ta);
        System.out.println("Profident Fund (PF)   : "+pf);
        double gs = s+da+ta;
        double ns = gs-pf;
        System.out.println("Gross Salary : "+gs);
        System.out.println("Net Salary   : "+ns);
    }   
}