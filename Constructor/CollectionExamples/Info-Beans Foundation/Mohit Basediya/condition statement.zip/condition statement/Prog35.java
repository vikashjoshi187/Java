/* WAP to find out the sum of individual digits of a 4 digit number & if sum is more than 
9 then again find out the sum of digits. */
import java.util.Scanner;
class Prog35
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any Four Digits Number : ");
        int a = sc.nextInt();
        int a1,a2,a3,a4,a5,a6,s,s2;
        if (a>999 && a<10000)
        {
            a1 = a/1000;
            System.out.println("First Digit  : "+a1);
            a2 = a%1000/100;
            System.out.println("Second Digit : "+a2);
            a3 = a%100/10;
            System.out.println("Third Digit  : "+a3);
            a4 = a%10;
            System.out.println("Fourth Digit : "+a4);
            s = a1+a2+a3+a4;
            System.out.println("Sum of All Individual Digits : "+s);

            if (s>9)
            {
                a5 = s/10;
                a6 = s%10;
                s2 = a5+a6;
                System.out.println("Again Sum of Digits : "+s2);
            }
        }
        else
            System.out.println("Not a Four Digit Number.");
    }
}