/* Program to check whether entered character is a digit or not & if yes , then replace 
it by (*) . */
import java.util.Scanner;
class Prog9
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter character : ");
        char ch = sc.next().charAt(0);
        if (ch>=48 && ch<=57)
        {
         ch=42;
         System.out.println("Character is digit & replaced by "+ch);
        }
        else
         System.out.println("Not a digit");
    }
}