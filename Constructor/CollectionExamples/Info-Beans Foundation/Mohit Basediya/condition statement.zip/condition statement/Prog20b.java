/* Program to get marks of 5 subjects from user and find out its grade using else if ladder. */
import java.util.Scanner ;
class Prog20b
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a,b,c,d & e : ");
        double a = sc.nextDouble();
        double b = sc.nextDouble();
        double c = sc.nextDouble();
        double d = sc.nextDouble();
        double e = sc.nextDouble();
        double total = a+b+c+d+e;
        double per = (a+b+c+d+e)/5.0;
        System.out.println("percent : "+per);
        if(per>=33&&per<50)
        System.out.println("Grade D");
            else if (per>=50&&per<60)
            System.out.println("Grade C");
                else if (per>=60&&per<75)
                System.out.println("Grade B");
                    else if (per>=75&&per<=100)
                    System.out.println("Grade A");
                        else 
                        System.out.println("Fail");
    }
}