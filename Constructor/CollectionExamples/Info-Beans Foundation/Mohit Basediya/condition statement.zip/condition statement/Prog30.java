// WAP to reverse 5 digit number.
import java.util.Scanner;
class Prog30
{
    public static void main(String args[])
    {
        int a,a1,a2,a3,a4,a5;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any 5 Digit Number");
        a = sc.nextInt();
        if (a>9999&&a<100000)
        {
            a1 = a/10000;
            a2 = (a%10000/1000)*10;
            a3 = (a%1000/100)*100;
            a4 = (a%100/10)*1000;
            a5 = (a%10)*10000;
            int r = a1+a2+a3+a4+a5;
            System.out.println("Reverse Of Number : "+r);
        }
        else
        System.out.println("Not A 5 Digit Number");
    }
}