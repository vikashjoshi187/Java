/* Program to find out whether entered number lies between 50 & 100 or not. */
import java.util.Scanner;
class Prog15
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number : ");
        int a = sc.nextInt();
        if (a>=50 && a<=100)
         System.out.println(a+" lies between 50 & 100");
        else 
         System.out.println(a+" not lies between 50 & 100");
    }
}   