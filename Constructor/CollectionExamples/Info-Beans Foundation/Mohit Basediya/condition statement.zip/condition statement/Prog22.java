/* The project basically gives the user the option to ask if he is renting a car [Y or N]: 
if Y is inputed, then it ask about 'C' for compact or 'F' for full size,
if the user selects compact the project display that the user has selected compact and
if the code display fullsize the the project display that the user has selected fullsize.
Then it ask user if they have a coupon or not by 'Y' or 'N' if the user answer Y for the
coupon the price is 7% off on 456.56 for compact car.
if the user answer N, the price is a normal 456.56. The fulllsize normal price is 460.50
& the price with a coupon is 7% off on 460.50. */
import java.util.Scanner;
class Prog22
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("will you want to rent a car [Y or N] : ");
        char r = sc.next().charAt(0);
        if (r=='Y')
        {
            System.out.println("User Wants to Rent a Car.");
            System.out.println("Enter 'C' for compact & 'F' for fullsize");
            char s = sc.next().charAt(0);
            if (s=='C')
            {
                System.out.println("The User has Selected Compact.");
                System.out.println("Price of Compact Car : ");
                double p = sc.nextDouble();
                System.out.println("You have a Coupon or Not ['Y'or'N'] : ");
                char c = sc.next().charAt(0);
                if (c=='Y')
                {                                                                              
                    System.out.println("Discount on Coupon : ");
                    double d = sc.nextDouble();
                    double dopc = p*(d/100);
                    double pc = p-dopc;
                    System.out.println("Price of Compact Car After Discount : "+pc);
                }
                else
                System.out.println("Price of Compact Car : "+p);
            }
            else //(s==F)
            {
                System.out.println("The User has Selected Fullsize.");
                System.out.println("Price of Fullsize Car : ");
                double pr = sc.nextDouble();
                System.out.println("You have a Coupon or Not ['Y'or'N'] : ");
                char cou = sc.next().charAt(0);
                if (cou=='Y')
                {
                    System.out.println("Discount on Coupon : ");
                    double dc = sc.nextDouble();
                    double dofc = pr*(dc/100);
                    double pf = pr-dofc;
                    System.out.println("Price of Fullsize Car after Discount : "+pf);
                }
                else
                System.out.println("Prize of Fullsize Car :"+pr);
            }
        }
        else 
        System.out.println("User Doesn't Wants to Rent a Car");
    }
}