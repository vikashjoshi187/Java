// Program 44 Repeat
import java.util.Scanner;
class Prog44r
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter the Type of Vehicle : \n1 = Vehicles With Two Axles & Single Rear Wheels\n2 = Vehicles With Two Axles & Dual Rear Wheels\n3 = Vehicles With Three Axles\n4 = Vehicles With Four Axles\n5 = Vehicles With Five Axles\n6 = Vehicles With Atleast Six Axles\n7 = Class 1 or 11(Including Recreational Vehicles) With Trailer\n8 = Two Axles Buses & Mini Buses\n9 = Three Axles Buses & Mini Buses\n10 = Motorcycle");
        int vt = sc.nextInt();
        System.out.println("You Have EZPass or not [Y or N]");
        char p = sc.next().charAt(0);
        if(vt==1)
        {
            if(p=='Y')
            {
                System.out.println("Enter Day : \n1 -> Sunday\n2 -> Monday\n3 -> Tuesday\n4 -> Wednesday\n5 -> Thrusday\n6 -> Friday\n7 -> Saturday");
                int d = sc.nextInt();
                if(d>=2&&d<=6)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6&&t<=10||t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $13.75");
                    }else
                    {
                    System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $11.75");
                    }
                }else
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $13.75");
                    }else
                    {
                       System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $11.75");
                    } 
                }
            }
            else
            {
                    System.out.println("You Select Cash Mode\nAmount of your toll is $16.00");
            }
        }
        else if (vt==2)
        {
            if(p=='Y')
            {
                System.out.println("Enter Day : \n1 -> Sunday\n2 -> Monday\n3 -> Tuesday\n4 -> Wednesday\n5 -> Thrusday\n6 -> Friday\n7 -> Saturday");
                int d = sc.nextInt();
                if(d>=2&&d<=4)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $38.00");
                    }else if (t>=10.1&&t<=15.99 || t>=20.1&&t<22)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $36.00");
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $33.00");
                    }
                }
                else if(d==5)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $38.00");
                    }else if (t>=10&&t<=15 || t>=21&&t<=24)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $36.00"); 
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $33.00");
                    }
                }
                else if (d==6)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $38.00");
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $36.00");
                    }
                }
                else if (d==7)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $38.00");
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $36.00");
                    }
                }
                else
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21.99)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $38.00");
                    }else if (t>=1&&t<=10)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $36.00");
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $33.00");
                    }
                }
            }
            else
            {
                    System.out.println("You Select Cash Mode\nAmount of your toll is $44.00");
            }
        }
        else if (vt==3)
        {
            if(p=='Y')
            {
                System.out.println("Enter Day : \n1 -> Sunday\n2 -> Monday\n3 -> Tuesday\n4 -> Wednesday\n5 -> Thrusday\n6 -> Friday\n7 -> Saturday");
                int d = sc.nextInt();
                if(d>=2&&d<=4)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $57.00");
                    }else if (t>=11&&t<=15 || t>=21&&t<22)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $54.00");
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $49.50");
                    }
                }
                else if(d==5)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $57.00");
                    }else if (t>=10&&t<=15 || t>=21&&t<=24)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $54.00"); 
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $49.50");
                    }
                }
                else if (d==6)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $57.00");
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $54.00");
                    }
                }
                else if (d==7)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $57.00");
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $54.00");
                    }
                }
                else
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21.99)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $57.00");
                    }else if (t>=1&&t<=10)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $54.00");
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $49.50");
                    }
                }
            }
            else
            {
                    System.out.println("You Select Cash Mode\nAmount of your toll is $66.00");
            }
        }
        else if (vt==4)
        {
            if(p=='Y')
            {
                System.out.println("Enter Day : \n1 -> Sunday\n2 -> Monday\n3 -> Tuesday\n4 -> Wednesday\n5 -> Thrusday\n6 -> Friday\n7 -> Saturday");
                int d = sc.nextInt();
                if(d>=2&&d<=4)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $76.00");
                    }else if (t>=11&&t<=15 || t>=21&&t<22)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $72.00");
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $66.00");
                    }
                }
                else if(d==5)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $76.00");
                    }else if (t>=10&&t<=15 || t>=21&&t<=24)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $72.00"); 
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $66.00");
                    }
                }
                else if (d==6)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $76.00");
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $72.00");
                    }
                }
                else if (d==7)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $76.00");
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $72.00");
                    }
                }
                else
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21.99)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $76.00");
                    }else if (t>=1&&t<=10)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $72.00");
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $66.00");
                    }
                }
            }
            else
            {
                    System.out.println("You Select Cash Mode\nAmount of your toll is $88.00");
            }
        }
        else if (vt==5)
        {
            if(p=='Y')
            {
                System.out.println("Enter Day : \n1 -> Sunday\n2 -> Monday\n3 -> Tuesday\n4 -> Wednesday\n5 -> Thrusday\n6 -> Friday\n7 -> Saturday");
                int d = sc.nextInt();
                if(d>=2&&d<=4)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $95.00");
                    }else if (t>=11&&t<=15 || t>=21&&t<22)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $90.00");
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $82.50");
                    }
                }
                else if(d==5)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $95.00");
                    }else if (t>=10&&t<=15 || t>=21&&t<=24)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $90.00"); 
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $82.50");
                    }
                }
                else if (d==6)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $95.00");
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $90.00");
                    }
                }
                else if (d==7)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $95.00");
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $90.00");
                    }
                }
                else
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21.99)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $95.00");
                    }else if (t>=1&&t<=10)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $90.00");
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $82.50");
                    }
                }
            }
            else
            {
                    System.out.println("You Select Cash Mode\nAmount of your toll is $110.00");
            }
        }
        else if (vt==6)
        {
            System.out.println("Enter Number of Additional Axles If More Than 6");
            int a = sc.nextInt();
            if(p=='Y')
            {
                System.out.println("Enter Day : \n1 -> Sunday\n2 -> Monday\n3 -> Tuesday\n4 -> Wednesday\n5 -> Thrusday\n6 -> Friday\n7 -> Saturday");
                int d = sc.nextInt();
                if(d>=2&&d<=4)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $"+(114+(a*19)));
                    }else if (t>=11&&t<=15 || t>=21&&t<22)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $"+(108+(a*18)));
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $"+(99+(a*16.50)));
                    }
                }
                else if(d==5)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $"+(114+(a*19)));
                    }else if (t>=10&&t<=15 || t>=21&&t<=24)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $"+(108+(a*18))); 
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $"+(99+(a*16.50)));
                    }
                }
                else if (d==6)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $"+(114+(a*19)));
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $"+(108+(a*18)));
                    }
                }
                else if (d==7)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $"+(114+(a*19)));
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $"+(108+(a*18)));
                    }
                }
                else
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21.99)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $"+(114+(a*19)));
                    }else if (t>=1&&t<=10)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $"+(108+(a*18)));
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $"+(99+(a*16.50)));
                    }
                }
            }
            else
            {
                    System.out.println("You Select Cash Mode\nAmount of your toll is $"+(132+(a*22)));
            }
        }
        else if (vt==7)
        {
            System.out.println("Enter Number of Additional Axles If More Than 6");
            int a = sc.nextInt();
            if(p=='Y')
            {
                System.out.println("Enter Day : \n1 -> Sunday\n2 -> Monday\n3 -> Tuesday\n4 -> Wednesday\n5 -> Thrusday\n6 -> Friday\n7 -> Saturday");
                int d = sc.nextInt();
                if(d>=2&&d<=6)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6&&t<=10||t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $"+(24.25+(a*10.50)));
                    }else
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $"+(22.25+(a*10.50)));
                    }
                }else
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $"+(24.25+(a*10.50)));
                    }else
                    {
                       System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $"+(22.25+(a*10.50)));
                    } 
                }
            }
            else
            {
                    System.out.println("You Select Cash Mode\nAmount of your toll is $"+(34+(a*18.00)));
            }
        }
        else if (vt>=8||vt<=9)
        {
            if(p=='Y')
            {
                System.out.println("Enter Day : \n1 -> Sunday\n2 -> Monday\n3 -> Tuesday\n4 -> Wednesday\n5 -> Thrusday\n6 -> Friday\n7 -> Saturday");
                int d = sc.nextInt();
                if(d>=2&&d<=6)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6&&t<=10||t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $14.00");
                    }else
                    {
                    System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $14.00");
                    }
                }else
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $14.00");
                    }else
                    {
                       System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $14.00");
                    } 
                }
            }
            else
            {
                    System.out.println("You Select Cash Mode\nAmount of your toll is $25.00");
            }
        }
        else
        {
            if(p=='Y')
            {
                System.out.println("Enter Day : \n1 -> Sunday\n2 -> Monday\n3 -> Tuesday\n4 -> Wednesday\n5 -> Thrusday\n6 -> Friday\n7 -> Saturday");
                int d = sc.nextInt();
                if(d>=2&&d<=6)
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=6&&t<=10||t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $12.75");
                    }else
                    {
                    System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $10.75");
                    }
                }else
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>24)
                    {
                        System.out.println("Invilid Time");
                    }
                    else if (t>=11&&t<=21)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $12.75");
                    }else
                    {
                       System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $10.75");
                    } 
                }
            }
            else
            {
                    System.out.println("You Select Cash Mode\nAmount of your toll is $16.00");
            }
        }
    }
}