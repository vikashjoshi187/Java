/* Program to find out compound interest if principal is greater than or equals to 500 
otherwise find out simple interest */
import java.util.Scanner ;
class Prog21
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter p,r,t : ");
        double p = sc.nextDouble();
        double r = sc.nextDouble();
        double t = sc.nextDouble();
        if(p>=500)
        {
            double ci = (p*Math.pow(1+r/100,t))-p;
            System.out.println("Compound Interest : "+ci);
        }
        else 
        {
            double si = (p*r*t)/100;
            System.out.println("Simple Interest : "+si);
        }
    }
}