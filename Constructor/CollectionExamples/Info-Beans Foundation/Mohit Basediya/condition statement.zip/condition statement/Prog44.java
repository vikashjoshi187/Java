/* Program 44. Amount of Money You Pay At The Toll. */
import java.util.Scanner;
class Prog44
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter the Type of Vehicle : \n1 = Vehicles With Two Axles & Single Rear Wheels\n2 = Vehicles With Two Axles & Dual Rear Wheels\n3 = Vehicles With Three Axles\n4 = Vehicles With Four Axles\n5 = Vehicles With Five Axles\n6 = Vehicles With Atleast Six Axles\n7 = Class 1 or 11(Including Recreational Vehicles) With Trailer\n8 = Two Axles Buses & Mini Buses\n9 = Three Axles Buses & Mini Buses\n10 = Motorcycle");
        int vt = sc.nextInt();
        System.out.println("Enter Day : \n1 -> Sunday\n2 -> Monday\n3 -> Tuesday\n4 -> Wednesday\n5 -> Thrusday\n6 -> Friday\n7 -> Saturday");
        int d = sc.nextInt();
        System.out.println("You Have EZPass or not [Y or N]");
        char p = sc.next().charAt(0);
        if(vt==1)
        {
            if(d>=1&&d<=5)
            {
               
                if (p=='Y')
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>=6&&t<=10||t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour");
                        System.out.println("Amount of your toll is $13.75");
                    }else
                    {
                    System.out.println("You Arrived in Off Peak Hour");
                    System.out.println("Amount of your toll is $11.75");
                    }
                }
                else
                   {
                    System.out.println("You Select Cash Mode\nAmount of your toll is $16.00");
                 }
            }
            else
            {
                if (p=='Y')
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>=11&&t<=21)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $13.75");
                    }else
                    {
                       System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $11.75");
                    }
                }
               else
                {
                    System.out.println("You Select Cash Mode\nAmount of your toll is $16.00");
                }
            }
        }
        else if (vt==2)
        {
            if(d>=2&&d<=4)
            {
                if (p=='Y')
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $38.00");
                    }else if (t>=11&&t<=15 || t>=21&&t<22)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $36.00");
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $33.00");
                    }
                }
                else{
                    System.out.println("Amount of your toll is $44.00");
                }
            }else if(d==5) 
            {
                if (p=='Y')
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>=6.1&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $38.00");
                    }else if (t>=10&&t<=15 || t>=21&&t<=24)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $36.00"); 
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $33.00");
                    }
                }
                else{
                    System.out.println("Amount of your toll is $44.00");
                }
            }else if (d==6)
            {
                if (p=='Y')
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>=6&&t<=10 || t>=16&&t<=20)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $38.00");
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $36.00");
                    }
                }else{
                    System.out.println("Amount of your toll is $44.00");
                }
            }else if (d==7)
            {
                 if (p=='Y')
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>=11&&t<=21)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $38.00");
                    }else 
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $36.00");
                    }
                }else{
                    System.out.println("Amount of your toll is $44.00");
                }
            }else 
            {
                if (p=='Y')
                {
                    System.out.println("Enter Time as 24 Hour Watch (From 1 to 24): ");
                    double t = sc.nextDouble();
                    if (t>=11&&t<=21.99)
                    {
                        System.out.println("You Arrived in Peak Hour\nAmount of your toll is $38.00");
                    }else if (t>=1&&t<=10)
                    {
                        System.out.println("You Arrived in Off Peak Hour\nAmount of your toll is $36.00");
                    }else
                    {
                        System.out.println("You Arrived in Overnight Hour\nAmount of your toll is $33.00");
                    }
                }else{
                    System.out.println("Amount of your toll is $44.00");
                }
            }
        }
    }
}