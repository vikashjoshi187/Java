/* Program to find out whether entered number is even or odd. */
import java.util.Scanner;
class Prog11
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number : ");
        int a = sc.nextInt();
        if (a%2==0)
         System.out.println("number is even");
        else 
         System.out.println("number is odd");
    }
}   