// WAP to Round Off 2 Digit Number.
import java.util.Scanner;
class Prog32
{
    public static void main(String args[])
    {
        int a,b,c;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any 2 Digit Number : ");
        a = sc.nextInt();
        if (a>9&&a<100)
        {
         b = a%10;
         if(b>=0&&b<5) 
         {a = a-b;
         System.out.println("Round Off : "+a);
         }
         else 
         {c = 10-b;
         a = a+c;
         System.out.println("Round Off : "+a);
         }
        }
        else
        System.out.println("Not A 2 Digit Number");
    }
}