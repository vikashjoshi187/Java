/* Check if both numbers are equal or not, if not then find out greatest number. */
import java.util.Scanner;
class Prog10
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a & b : ");
        int a = sc.nextInt(),b = sc.nextInt();
        if (a==b)
         System.out.println("both numbers are equal");
        else
        {
            if (a>b)
             System.out.println(a+" is greater");
            else
             System.out.println(b+" is greater");
        }
    }
} 