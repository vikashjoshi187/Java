/* Program to take nationality as 'i'or'I' for Indian from user, & if it is an indian 
then take age from it & check whether he or she is eligible to vote or not. */
import java.util.Scanner;
class Prog19
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter Nationality : ");
        char ch = sc.next().charAt(0);

        if(ch=='I' || ch=='i')
        {
            System.out.println("Enter Age : ");
            int age =  sc.nextInt();
            if (age>=18)
            System.out.println("Eligible");
            else
            System.out.println("Not Eligible");
        }
        else
        System.out.println("User is Not Indian.");
    }
} 