/* Program to find out greater numbers among three numbers & test for all possible 
equalities. */
import java.util.Scanner;
class Prog16
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a,b & c : ");
        int a = sc.nextInt();
        int b = sc.nextInt();              
        int c = sc.nextInt();
        if (a==b && b==c)
        System.out.println("all numbers are equal");
        else if (a==b&&a>c)
        System.out.println(a+" & "+b+" are equal & greater than "+c);
        
        else if (a==b&&a<c)
        System.out.println(a+" & "+b+" are equal but less than "+c);
        
        else if (b==c&&b>a)
        System.out.println(b+" & "+c+" are equal & greater than "+a);
        
        else if (b==c&&b<a)
        System.out.println(b+" & "+c+" are equal but less than "+a);
        
        else if (a==c&&a>b)
        System.out.println(a+" & "+c+" are equal & greater than "+b);
        
        else if (a==c&&a<b)
        System.out.println(a+" & "+c+" are equal but less than "+b);
        
        else if ((a>b)||(a>c))
        System.out.println(a+" is greater");
        
        else if (b>c)
        System.out.println(b+" is greater");
        
        else
        System.out.println(c+" is greater");
    }
}