/* Find the Result of following (accept values for variables used in right side)
a. y = x-2+3*x-7 (print value of y)
b. y = x++ + ++x (print value of x & y)
c. z = x++ - --y - --x + x++ (print value of x,y & z)
d. z = x&&y||!(x||y) (print value of z) */
import java.util.Scanner;
class Prog39
{
    public static void main(String args[])
    {
        float x,y,z;
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter Value of x : ");
        x = sc.nextInt();
        y = x-2+3*x-7;
        System.out.println("Value of y : "+y);
        y = x++ + ++x;
        System.out.println("Value of x : "+x);
        System.out.println("Value of y : "+y);
        z = x++ - --y - --x + x++;
        System.out.println("Value of x : "+x);
        System.out.println("Value of y : "+y);
        System.out.println("Value of z : "+z);
    }
}