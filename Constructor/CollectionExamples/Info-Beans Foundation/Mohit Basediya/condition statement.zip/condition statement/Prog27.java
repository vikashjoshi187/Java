/* Write a program that accepts six digit number & find out the sum of first & last digits.*/
import java.util.Scanner;
class Prog27
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any Six Digits Number : ");
        int a = sc.nextInt();
        int a1,a2,sum;
        if (a>99999 && a<1000000)
        {
            a1 = a/100000;
            System.out.println("First digit : "+a1);
            a2 = a%10;
            System.out.println("Last digit  : "+a2);
            sum = a1+a2;
            System.out.println("Sum of First & Last digits : "+sum);
        }
        else
            System.out.println("Not a Six Digit Number.");
    }
}