// WAP to count number of even or odd digits in a 5 digit number.
import java.util.Scanner;
class Prog34
{
    public static void main(String args[])
    {
        int a,a1,a2,a3,a4,a5,e=0,o=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any Five Digits Number : ");
        a = sc.nextInt(); 
        if (a>9999 && a<100000)
        {  
            a1 = a/10000;
            a2 = a%10000/1000;
            a3 = a%1000/100;
            a4 = a%100/10;
            a5 = a%10;
            
            if (a1%2==0){
                System.out.println(a1+" is even");
                e = ++e;
            } else{
                System.out.println(a1+" is odd");
                o = o+1;
            }
            if (a2%2==0){
                System.out.println(a2+" is even");
                e = ++e;
            } else{
                System.out.println(a2+" is odd");
                o = o+1;
            }
            if (a3%2==0){
                System.out.println(a3+" is even");
                e = ++e;
            } else{
                System.out.println(a3+" is odd");
                o = o+1;
            }
            if (a4%2==0){
                System.out.println(a4+" is even");
                e = ++e;
            } else{
                System.out.println(a4+" is odd");
                o = o+1;
            }
            if (a5%2==0){
                System.out.println(a5+" is even");
                e = ++e;
            } else{
                System.out.println(a5+" is odd");
                o = o+1;
            }
            System.out.println("Number of Even Digit : "+e);
            System.out.println("Number of Odd Digit  : "+o);
        }
        else 
        System.out.println("Not a 5 Digit Number");
    }
}