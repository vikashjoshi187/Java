/* WAP to enter three subjects marks (out of 100). Check if Student is Pass & Fail, only if 
he/she scores greater than 75 in each subject & average of all three subject marks should
also be greater than 80. */
import java.util.Scanner;
class Prog38
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter Marks of Three Subjects : ");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        
        if (a<=100&&b<=100&&c<=100)
        {
            if (a>75&&b>75&&c>75)
            {
                double avg = (a+b+c)/3.0;
                System.out.println("Average : "+avg);
                if(avg>80)
                {
                    System.out.println("Student is Pass");
                }
                else 
                {
                    System.out.println("Student is Fail");
                }
            }
            else
            {
                 System.out.println("Student is Fail");
            }
        }
        else
        {
            System.out.println("Invalid Marks.");
        }
    }
}