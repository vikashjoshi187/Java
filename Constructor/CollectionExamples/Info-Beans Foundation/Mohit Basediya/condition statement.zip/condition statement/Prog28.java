/* Write a program that accepts five digit number & replace the first & last digits. 
Ex:- i/p = 45872,o/p = 25874. */
import java.util.Scanner;
class Prog28
{
    public static void main (String args[])
    {
        int a,a1,a2,a3,sfml;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any Five Digits Number : ");
        a = sc.nextInt();
        if (a>9999 && a<100000)
        {
            a1 = a/10000;
            a2 = (a%10000/10)*10;
            a3 = (a%10)*10000;
            sfml=a1+a2+a3;
            System.out.println("Replacing of First & Last Digits : "+sfml);
        }
        else
            System.out.println("Not a Five Digit Number.");
    }
}