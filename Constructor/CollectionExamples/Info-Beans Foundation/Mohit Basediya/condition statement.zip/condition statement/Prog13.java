/* Program to ckeck whether entered number is divisible by 75 or not. */
import java.util.Scanner;
class Prog13
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number : ");
        int a = sc.nextInt();
        if (a%75==0)
         System.out.println(a+" is divisible by 75");
        else 
         System.out.println(a+" is not divisible by 75");
    }
}   