/* WAP to take 6 digit number from user & check whether it is palindrome or not. */
import java.util.Scanner;
class Prog40
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter Any 6 Digit Number : ");
        int d = sc.nextInt();
        int a1,a2,a3,a4,a5,a6;
        if (d>99999 && d<1000000)                        // Prog40
        {
            a1 = d/100000;
            System.out.println("First digit  : "+a1);
            a2 = d%100000/10000;
            System.out.println("Second Digit : "+a2);
            a3 = d%10000/1000;
            System.out.println("Third Digit  : "+a3);
            a4 = d%1000/100;
            System.out.println("Fourth Digit : "+a4);
            a5 = d%100/10;
            System.out.println("Fifth Digit  : "+a5);
            a6 = d%10;
            System.out.println("Last digit   : "+a6);
            if (a1==a6 && a2==a5 && a3==a4)
            {
                System.out.println("Number is Palindrome : "+d);
            }
            else
            {
                System.out.println("Number is Not Palindrome "+d);
            }
        }
        else
        {
            System.out.println("Not a Six Digit Number.");
        }
    }
}