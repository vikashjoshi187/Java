/* WAP to round off all the numbers which lies in between 1 to 4 digit numbers. */
import java.util.Scanner;
class Prog42
{
    public static void main(String args[])
    {
        int a,b,c;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any Number (digit 1 to 4) : ");
        a = sc.nextInt();
        if (a>0&&a<10000) 
        {
         /*   if (a>0&&a<5)
            {
                a=a-a;
                System.out.println("Round Off : "+a);
            }else{
                b=10-a;
                a=a+b;
                System.out.println("Round Off : "+a);
            }
        }
        else if (a>9&&a<10000)
        {
            b = a%10;
            if(b>=0&&b<5)
            {
                a = a-b;
                System.out.println("Round Off Value : "+a);
            }else{
                c = 10-b;
                a = a+c;
                System.out.println("Round Off Value : "+a);
            }   
        }*/ b=a%10;
            c=a/10;
            if(b>=0&&b<5)
            {
                a=c*10;
                System.out.println(a);
            } 
            else
            {
                a=(c+1)*10;
                System.out.println(a);
            }
            }
            else 
        {
            System.out.println("Not In Range");
        }
        
    }
}