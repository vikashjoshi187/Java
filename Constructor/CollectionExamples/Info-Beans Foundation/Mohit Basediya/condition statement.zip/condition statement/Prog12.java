/* Program to find out whether entered number is +ve or -ve. */
import java.util.Scanner;
class Prog12
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number : ");
        int a = sc.nextInt();
        if (a>0)
         System.out.println(a+" is positive");
        else if (a<0)
         System.out.println(a+" is negative");
         else 
          System.out.println(a+" is neutral");
    }
}   