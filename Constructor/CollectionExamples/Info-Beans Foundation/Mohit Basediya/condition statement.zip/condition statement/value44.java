import java.util.*;
public class value44 
{
    public static void main(String[] args) 
{
     Scanner s=new Scanner(System.in);
     System.out.println("enter the type of vehcle in between 1 to 10");
     int vhecl =s.nextInt();
     System.out.println("enter days--> mon->1 | tue->2 | wed->3 | thus->4 | fri->5 | sut->6 | sun->7 ");
     int day =s.nextInt();
     System.out.println("enter time");
     double time=s.nextDouble();
    if((vhecl>=1&&vhecl<=10)&&(day>=1&&day<=7)&&(time>=0&&time<=24))
    {
            if(vhecl==1)
            {   System.out.println("enter 'Y' for have pass 'N' for cash");
                char pass=s.next().charAt(0);
                if ((day>=1&&day<=5)&&((time>=6&&time<=10)||(time>=16&&time<=20))){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in week day peak hour pass amount is: 13.75");}
                    else{System.out.println(vhecl+" : type cash amount is: 16.00");}}
                    // week end peak hour
                else if((day ==7 || day==6)&&(time>=11 && time<=21)){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in week end day peak hour pass amount is: 13.75");}
                    else{System.out.println(vhecl+": type cash amount is: 16.00");}} 
                    //off  peak hour   
                else{if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in off pick hour amount is: 11.75");}
                    else{System.out.println(vhecl+"in : type cash amount is: 16.00");}}
            }
            else if(vhecl==2)
            {
                { System.out.println("enter 'Y' for have pass 'N' for cash");
                char pass=s.next().charAt(0);
                // peak hour in week day
                if ((day>=1&&day<=5)&&((time>=6&&time<=10)||(time>=16&&time<=20))){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week day peak hour pass amount is: 38");}
                    else{System.out.println(vhecl+" : type cash amount is: 44");}}
                    // peak hour for week end
                else if((day ==6 || day==7)&&(time>=11 && time<=21)){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week end day peak hour pass amount is: 38");}
                    else{System.out.println(vhecl+": type cash amount is: 44");}}
                // night hour   
                else if((day==1 || day==2 || day==3 || ((day==4)&&(time>=0&&time<=6)) || (day==7&&(time>=22&&time<=24)))&&((time>=22&&time<=24)||(time>=0&&time<=6))){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+":night hour amount is: 33");}
                    else{System.out.println(vhecl+": type cash amount is: 44");}}
                // off peak hour    
                else{
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in off peak hour amount is: 36");}
                    else{System.out.println(vhecl+": type cash amount is: 44");}}}
            }    
             else if(vhecl==3)
            {
                {   System.out.println("enter 'Y' for have pass 'N' for cash");
                char pass=s.next().charAt(0);
                if ((day>=1&&day<=5)&&((time>=6&&time<=10)||(time>=16&&time<=20))){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in week day peak hour pass amount is: 57");}
                    else{System.out.println(vhecl+" : type cash amount is: 66");}}
                // peak hour for week end    
                else if((day ==7 || day==6)&&(time>=11 && time<=21)){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week end day peak hour pass amount is: 57");}
                    else{System.out.println(vhecl+" : type cash amount is: 66");}}    
                //night hour    
                else if((day==1 || day==2 || day==3 || ((day==4)&&(time>=0&&time<=6)) || (day==7&&(time>=22&&time<=24)))&&((time>=22&&time<=24)&&(time>=0&&time<=6))){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" :night hour amount is: 49.50");}
                    else{System.out.println(vhecl+": type cash amount is: 66");}}
                // off peak hour    
                else{
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in off peak hour amount is: 54");}
                    else{System.out.println(vhecl+": type cash amount is: 66");}    
                    }}
            }
            else if(vhecl==4)
            {
                {   System.out.println("enter 'Y' for have pass 'N' for cash");
                char pass=s.next().charAt(0);
                if ((day>=1&&day<=5)&&(time>=6&&time<=10)||(time>=16&&time<=20)){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week day peak hour pass amount is: 76");}
                    else{System.out.println(vhecl+"  type cash amount is: 88");}}
                // peak hour for week end    
                else if((day ==7 || day==6)&&(time>=11 && time<=21)){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week end day peak hour pass amount is: 76");}
                    else{System.out.println(vhecl+"  type cash amount is: 88");}}
                //night hour    
                else if((day==1 || day==2 || day==3 || ((day==4)&&(time>=0&&time<=6)) || (day==7&&(time>=22&&time<=24)))&&((time>=22&&time<=24)||(time>=0&&time<=6))){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+":night hour amount is: 66");}
                    else{System.out.println(vhecl+" type cash amount is: 88");}}
                // off peak hour    
                else{ if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in off peak hour amount is: 72");}
                    else{System.out.println(vhecl+" type cash amount is: 88");}    
                    }}
            }
            else if(vhecl==5)
            {
                System.out.println("enter 'Y' for have pass 'N' for cash");
                char pass=s.next().charAt(0);
                if ((day>=1&&day<=5)&&(time>=6&&time<=10)||(time>=16&&time<=20)){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week day peak hour pass amount is: 95");}
                    else{System.out.println(vhecl+" type cash amount is: 110");}}
                // peak hour for week end    
                else if((day ==7 || day==6)&&(time>=11 && time<=21)){
                     if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in week end day peak hour pass amount is:  95");}
                     else{System.out.println(vhecl+" type cash amount is: 110");}}    
                //night hour    
                else if((day==1 || day==2 || day==3 || ((day==4)&&(time>=0&&time<=6)) || (day==7&&(time>=22&&time<=24)))&&((time>=22&&time<=24)||(time>=0&&time<=6))){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" :night hour amount is: 82.50");}
                    else{System.out.println(vhecl+"type cash amount is: 110");}}
                // off peak hour    
                else{
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in off peak hour amount is: 90");}
                    else{System.out.println(vhecl+"type cash amount is: 110");}}
            }
            else if(vhecl==6)
            {
                System.out.println("enter 'Y' for have pass 'N' for cash");
                char pass=s.next().charAt(0);
                
                if ((day>=1&&day<=5)&&((time>=6&&time<=10)||(time>=16&&time<=20))){
                    System.out.println("enter number of axles to add");
                    int axles=s.nextInt();
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week day peak hour pass amount is:"+(114+(axles*19)));}
                    else{System.out.println(vhecl+" type cash amount is: "+(132+(axles*22)));}}
                 // peak hour for week end    
                 else if((day ==7 || day==6)&&(time>=11 && time<=21)){
                    System.out.println("enter number of axles to add");
                    int axles=s.nextInt();  
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week end day peak hour pass amount is:"+(114+(axles*19)));}
                    else{System.out.println(vhecl+" type cash amount is: "+(132+axles*22));}}    
                 // night hour   
                else if((day==1 || day==2 || day==3 || ((day==4)&&(time>=0&&time<=6)) || (day==7&&(time>=22&&time<=24)))&&((time>=22&&time<=24)||(time>=0&&time<=6))){
                    System.out.println("enter number of axles to add");
                    int axles=s.nextInt();
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" :night hour amount is: "+(99+(axles*16.50)));}
                    else{System.out.println(vhecl+"type cash amount is:"+(132.0+(axles*22)));}}
                 // off peak hour
                 else{System.out.println("enter number of axles to add");
                    int axles=s.nextInt();
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in off peak hour amount is: "+(108.00+(axles*18.0)));}
                    else{System.out.println(vhecl+" type cash amount is:"+(132.0+(axles*22.0)));}}  
            }
            else if(vhecl==7)
            {
                System.out.println("enter 'Y' for have pass 'N' for cash");
                char pass=s.next().charAt(0);
                // peak hour for week days
                if ((day>=1&&day<=5)&&((time>=6&&time<=10)||(time>=16&&time<=20))){
                    System.out.println("enter number of axles to add");
                    int axles=s.nextInt(); 
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week day peak hour pass amount is:"+(24.25+(axles*10.50)));}
                    else{System.out.println(vhecl+" type cash amount is: "+(34+(axles*18.0)));}}
                 // peak hour for week end    
                else if((day ==7 || day==6)&&(time>=11 && time<=21)) {
                    System.out.println("enter number of axles to add");
                    int axles=s.nextInt(); 
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week end day peak hour pass amount is:"+(24.25+(axles*10.50)));}
                    else{System.out.println(vhecl+" type cash amount is: "+(34.0+(axles*18.0)));}}  
                 // off peak hour
                else{System.out.println("enter number of axles to add");
                    int axles=s.nextInt();
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in off pick hour amount is: "+(22.25+(axles*10.50)));}
                    else{System.out.println(vhecl+"in type cash amount is: 110"+(34.0+(axles*18.0)));}}  
            }
            else if(vhecl==8 || vhecl==9)
            {
                System.out.println("enter 'Y' for have pass 'N' for cash");
                char pass=s.next().charAt(0);
                // peak hour for week days
                if ((day>=1||day<=5)&&((time>=6&&time<=10)||(time>=16&&time<=20))){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week day peak hour pass amount is: 14");}
                    else{System.out.println(vhecl+" type cash amount is: 25");}}
                // peak hour for week end    
                else if((day ==7 || day==6)&&(time>=11 && time<=21)){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week end day peak hour pass amount is: 14");}
                    else{System.out.println(vhecl+" type cash amount is: 25");}}    
                else{ 
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in off pick hour amount is: 14");}
                    else{System.out.println(vhecl+"type cash amount is: 25.00");}}
            }
            else if(vhecl==10)
            {
                System.out.println("enter 'Y' for have pass 'N' for cash");
                char pass=s.next().charAt(0);
                // peak hour for week days
                if ((day>=1&&day<=5)&&((time>=6&&time<=10)||(time>=16&&time<=20))){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week day peak hour pass amount is: 12.75");}
                    else{System.out.println(vhecl+" type cash amount is: 16.00");}}
                 // peak hour for week end    
                else if((day ==7 || day==6)&&(time>=11 && time<=21)){
                    if (pass=='Y'||pass=='y'){System.out.println(vhecl+" : type in week end day peak hour pass amount is: 12.75");}
                    else{System.out.println(vhecl+" type cash amount is: 16.00");}}    
                else{ if (pass=='Y'||pass=='y'){System.out.println(vhecl+": type in off pick hour amount is:10.75");}
                    else{System.out.println(vhecl+"type cash amount is: 16.00");}}
            }  
      }else{System.out.println("please enter valid detail");
      }
    }
 }   