/* WAP to take 3 digit number from user & check whether it is armstrong or not. */
import java.util.Scanner;
class Prog41
{
    public static void main(String args[])
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter Any 3 Digit Number : ");
        int d = sc.nextInt();
        int a1,a2,a3;
        if (d>99 && d<1000)
        {
            a1 = d/100;
            System.out.println("First Digit  : "+a1);
            a2 = d%100/10;
            System.out.println("Second Digit : "+a2);
            a3 = d%10;
            System.out.println("Third Digit  : "+a3);
            double sum = (Math.pow(a1,3)+Math.pow(a2,3)+Math.pow(a3,3));
            if (d==sum)
            {
                System.out.println("Number is Armstrong");
            }
            else
            {
                System.out.println("Number is Not Armstrong");
            }
        }
        else
        { 
            System.out.println("Not a 3 Digit Number");
        }
    }
}