// Program to check whether entered character is a digit or not.
import java.util.Scanner;
class Prog5
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter character : ");
        char ch = sc.next().charAt(0);
        if(ch>=48 && ch<=57)
         System.out.println(ch+" is Digit");
        else 
         System.out.println(ch+" is not a Digit");       
    }
}