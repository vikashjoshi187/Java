// WAP showing the concept of quadratic equation.
import java.util.Scanner;
class Prog43
{
    public static void main (String args[])
    {
        double a,b,c,d,r1,r2;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Value of a,b & c : ");
         a = sc.nextInt();
         b = sc.nextInt();
         c = sc.nextInt();
         d = b*b-4*a*c;
         System.out.println(d);
        
        if (d>0)
        {
            System.out.println("Roots are Real And Unequal");
            r1 = (-b+Math.sqrt(d))/(2*a);
            r2 = (-b-Math.sqrt(d))/(2*a);
            System.out.println("Root 1 : "+r1);
            System.out.println("Root 2 : "+r2);
        }
        else if (d==0)
        {
            System.out.println("Roots are Real And equal");
            r1 = r2 = -b/(2*a);
            System.out.println("Root 1 & Root 2 : "+r1);
        }
        else 
        {
            System.out.println("Roots are Imaginary");
            double rp = -b/(2*a);
            double ip = Math.sqrt(-d)/(2*a);
            System.out.printf("Root 1 : %.2f+%.2fi",rp,ip);
            System.out.printf("\nRoot 2 : %.2f-%.2fi\n",rp,ip);
        }        
    }
}