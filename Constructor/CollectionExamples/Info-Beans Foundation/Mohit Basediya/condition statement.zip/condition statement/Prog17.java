/* Program to check whether entered character falls in the category of special symbol 
or not. */
import java.util.Scanner;
class Prog17
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter a character : ");
        char ch = sc.next().charAt(0);
        if ((ch>=65&&ch<=90)||(ch>=97&&ch<=122))
        {
        System.out.println(ch+" is Not a Special Symbol.");
        }
          else  if (ch>=48&&ch<=57)
          {
            System.out.println(ch+" is Not a Special Symbol.");
          }
             else 
              {
               System.out.println(ch+" is a Special Symbol.");
              }
       
    }
}