/* WAP for generating electricity Bill. Accept last month unit & current month unit from
user, then calculate & print bill amount according to following condition
For Units 
00-100  : Charges is 2 Rs/unit
101-200 : Charges is 3 Rs/unit
201-300 : Charges is 4 Rs/unit
>300    : Charges is 5 Rs/unit */
import java.util.Scanner;
class Prog37
{
    public static void main (String args[])
    {
        int lm,cm,u,a;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Last Month & Current Month Unit : ");
        lm = sc.nextInt();
        cm = sc.nextInt();
        u = cm-lm;
        System.out.println("Unit : "+u);
        if(u>=0&&u<=100)
        {
            a = u*2;
            System.out.println("Amount of Bill : "+a);
        }
        else if (u>=101&&u<=200)
        {
            a = u*3;
            System.out.println("Amount of Bill : "+a);
        }
        else if (u>=201&&u<=300)
        {
            a = u*4;
            System.out.println("Amount of Bill : "+a);
        }
        else 
        {
            a = u*5;
            System.out.println("Amount of Bill : "+a);
        }
    }
}