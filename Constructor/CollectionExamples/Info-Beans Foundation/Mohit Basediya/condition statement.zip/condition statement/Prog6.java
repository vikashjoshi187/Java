// Program to check whether entered character is a $ or @ by its ASCII value
import java.util.Scanner;
class Prog6
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter character : ");
        char ch = sc.next().charAt(0);
        if(ch==36)
         System.out.println((int)ch+" is ASCII value of $");
        else if (ch==64)
         System.out.println((int)ch+" is ASCII value of @");
         else
         System.out.println("false");       
    }
}