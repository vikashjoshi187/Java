/* Write a program that accepts three digit number & find out the sum of all the individual 
digits. */
import java.util.Scanner;
class Prog24
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter any Three Digits Number : ");
        int a = sc.nextInt();
        int a1,a2,a3,sum;
        if (a>99 && a<1000)
        {
            a1 = a/100;
            System.out.println("First Digit  : "+a1);
            a2 = a%100/10;
            System.out.println("Second Digit : "+a2);
            a3 = a%10;
            System.out.println("Third Digit  : "+a3);
            sum = a1+a2+a3;
            System.out.println("Sum of All Individual Digits : "+sum);
        }
        else
            System.out.println("Not a Three Digit Number.");
    }
}