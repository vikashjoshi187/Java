/* Write a program that accepts five digit number & find out the sum of all the individual 
digits. */
import java.util.Scanner;
class Prog26
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Any Five Digits Number : ");
        int a = sc.nextInt();
        int a1,a3,a5,a7,a8,sum;
        if (a>9999 && a<100000)
        {
            a1 = a/10000;
            System.out.println("First Digit  : "+a1);
            a3 = a%10000/1000;
            System.out.println("Second Digit : "+a3);
            a5 = a%1000/100;
            System.out.println("Third Digit  : "+a5);
            a7 = a%100/10;
            System.out.println("Fourth Digit : "+a7);
            a8 = a%10;
            System.out.println("Fifth Digit  : "+a8);
            sum = a1+a3+a5+a7+a8;
            System.out.println("Sum of All Individual Digits : "+sum);
        }
        else
            System.out.println("Not a Five Digit Number.");
    }
}