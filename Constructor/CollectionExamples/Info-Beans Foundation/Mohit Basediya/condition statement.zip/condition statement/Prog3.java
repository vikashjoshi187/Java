// Program to check whether entered character is in lowercase or not.
import java.util.Scanner;
class Prog3
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter character : ");
        char ch = sc.next().charAt(0);
        if(ch>=97 && ch<=122)
         System.out.println(ch+" : Lowercase");
        else
         System.out.println(ch+" : Not Lowercase");
    }
}