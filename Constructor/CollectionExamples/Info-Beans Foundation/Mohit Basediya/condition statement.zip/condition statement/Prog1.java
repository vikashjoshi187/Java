// Program to print character of all the ASCII values from 91 to 96.
import java.util.Scanner;
class Prog1
{
    public static void main (String args[])
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("Enter ASCII value : ");
        int asc = sc.nextInt();
        if(asc>=91 && asc<=96)
        System.out.println("Print Character : "+(char)asc);
        else
        System.out.println("Not in Range");
    }
}     /* char ch = sc.next().charAt(0);
         if(ch>=91 && ch<=96)
         System.out.println(ch+" & ASCII value of char : "+(int)ch);*/