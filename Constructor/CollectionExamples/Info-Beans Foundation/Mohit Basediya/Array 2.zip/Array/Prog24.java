import java.util.Scanner;
class Prog24 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size Of Array -> ");
        int size = sc.nextInt();
        int arr[] = new int[size];
        System.out.println("Enter Elements -> \n");
        for (int i = 0; i < size; i++) {
            System.out.println("Element -> " + i + "->");
            arr[i] = sc.nextInt();
        }
        System.out.println("Given Array Is -> ");
        for (int i = 0; i < size; i++) {
            System.out.print(arr[i] + "\t");
        }
        int max = arr[0];
        for (int i = 0; i < size; i++) {
            if (arr[i]>max){
                max = arr[i];
            }
        }
        System.out.println("\n\nLargest Element Of Array Is -> "+max);
    }
}