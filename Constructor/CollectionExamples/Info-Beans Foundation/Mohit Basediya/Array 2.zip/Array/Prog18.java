import java.util.Scanner;
class Prog18 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size Of Array -> ");
        int size = sc.nextInt();
        int arr[] = new int[size+1];
        
        System.out.println("Enter Elements -> \n");
        for (int i = 0; i < size; i++) {
            System.out.println("Element " + i + " -> ");
            arr[i] = sc.nextInt();
        }
        
        System.out.println("\nEnter Index Number You Want To Add -> ");
        int index = sc.nextInt();
        System.out.println("\nEnter New Value Of Index -> ");
        int value = sc.nextInt();
        System.out.println("\nOriginal Array -> ");
        for (int i = 0; i < size; i++){
            System.out.print(arr[i]+"\t");
        }
        
        for (int i = size-1; i >= index; i--){
            arr[i+1] = arr[i];
        }
        arr[index] = value;
        
        System.out.println("\n\nArray After Inserting Element -> ");
        for (int i = 0; i < size+1; i++) {
            System.out.print(arr[i]+"\t");
        }
        System.out.println();
    }
}
