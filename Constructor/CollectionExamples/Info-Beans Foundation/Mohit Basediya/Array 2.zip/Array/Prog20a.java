import java.util.Scanner;
class Prog20a {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size Of Array-1 -> ");
        int size = sc.nextInt();
        int arr[] = new int[size];
        System.out.println("Enter Elements -> \n");
        for (int i = 0; i < size; i++) {
            System.out.println("Element " + i + " -> ");
            arr[i] = sc.nextInt();
        }
        System.out.println("Enter Size Of Array-2 -> ");
        int size1 = sc.nextInt();
        int arr1[] = new int[size1+size];
        System.out.println("Enter Elements -> \n");
        for (int i = 0; i < size1; i++) {
            System.out.println("Element " + i + " -> ");
            arr1[i] = sc.nextInt();
        }
        int a = 0;
        for (int i = 0; i < size1; i++,a++){
            arr1[a+size] = arr1[i];
        }
        for (int i = 0; i < size; i++){
                arr1[i] = arr[i];
        }
        System.out.println("Merging Of Both Arrays -> ");
        for (int i = 0; i < arr1.length; i++){
            System.out.print(arr1[i]+"\t");
        }
        System.out.println();
    }
}