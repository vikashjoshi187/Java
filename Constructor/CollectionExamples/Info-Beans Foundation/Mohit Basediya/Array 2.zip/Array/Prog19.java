import java.util.Scanner;
class Prog19 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size Of Array -> ");
        int size = sc.nextInt();
        int arr[] = new int[size];
        
        System.out.println("Enter Elements -> \n");
        for (int i = 0; i < size; i++) {
            System.out.println("Element " + i + " -> ");
            arr[i] = sc.nextInt();
        }
        
        System.out.println("\nEnter Index Number You Want To Delete -> ");
        int index = sc.nextInt();
        System.out.println("\nOriginal Array -> ");
        for (int i = 0; i < size; i++) {
            System.out.print(arr[i] + "\t");
        }
        
        for (int i = index; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }
        
        System.out.println("\n\nArray After Inserting Element -> ");
        for (int i = 0; i < size - 1; i++) {
            System.out.print(arr[i] + "\t");
        }
        System.out.println();
    }
}