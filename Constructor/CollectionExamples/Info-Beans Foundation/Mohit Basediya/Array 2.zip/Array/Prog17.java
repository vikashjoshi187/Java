import java.util.Scanner;
class Prog17 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size Of Array -> ");
        int size = sc.nextInt();
        int arr[] = new int[size];
        System.out.println("Enter Elements -> \n");
        for (int i = 0; i < arr.length; i++) {
            System.out.println("Element " + i + " -> ");
            arr[i] = sc.nextInt();
        }
        System.out.println("\nReverse Elements -> ");
        for (int i = 0; i < arr.length; i++) {
            int rev = 0, rem = 0;
            while (arr[i] > 0) {
                rem = arr[i] % 10;
                rev = rev * 10 + rem;
                arr[i] = arr[i] / 10;
            }
            System.out.print(rev + "\t");
        }
        System.out.println();
    }
}