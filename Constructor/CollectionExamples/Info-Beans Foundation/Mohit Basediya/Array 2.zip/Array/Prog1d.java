class Prog1d {
    public static void main(String[] args) {
        int arr[] = { 91, 92, 95, 97, 90 };
        System.out.println("Marks Of 5 Subjects Are -> ");
        int i = 0;
        do{
            System.out.print("arr["+i+"] -> ");
            System.out.println(arr[i]);
            i++;
        }while (i < 5);
    }
}