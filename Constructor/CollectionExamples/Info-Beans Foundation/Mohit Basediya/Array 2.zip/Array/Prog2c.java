class Prog2c {
    public static void main(String[] args) {
        char arr[] = { 'H','E','L','L','O',' ','A','N','D','R','E','W'};
        int i = 0;
        while (i < arr.length) {
            System.out.print(arr[i]);
            i++;
        }System.out.println();
    }
}