import java.util.Scanner;
class Prog5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size Of Array -> ");
        int size = sc.nextInt();
        int arr[] = new int[size];
        int sum = 0;
        System.out.println("Enter Elements -> \n");
        for (int i = 0; i < arr.length; i++) {
            System.out.println(i + " Element -> ");
            arr[i] = sc.nextInt();
        }
        for (int i = 0; i < arr.length; i++) {
            sum = sum + arr[i];
        }
        System.out.println("\nSum of All Elements -> " + sum);
    }
}