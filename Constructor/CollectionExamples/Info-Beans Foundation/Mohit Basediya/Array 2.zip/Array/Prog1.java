class Prog1 {
    public static void main(String[] args) {
        int arr[] = { 91, 92, 95, 97, 90 };
        System.out.println("Marks Of 5 Subjects Are -> ");
        System.out.println("arr[0] : " + arr[0]);
        System.out.println("arr[1] : " + arr[1]);
        System.out.println("arr[2] : " + arr[2]);
        System.out.println("arr[3] : " + arr[3]);
        System.out.println("arr[4] : " + arr[4]);
    }
}