class Prog2d {
    public static void main(String[] args) {
        char arr[] = { 'H','E','L','L','O',' ','A','N','D','R','E','W'};
        int i = 0;
        do{
            System.out.print(arr[i]);
            i++;
        }
        while (i < arr.length);
        System.out.println();
    }
}