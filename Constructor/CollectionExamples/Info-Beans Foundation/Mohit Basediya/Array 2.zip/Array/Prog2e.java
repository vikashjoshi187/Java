class Prog2e {
    public static void main(String[] args) {
        char arr[] = { 'H','E','L','L','O',' ','A','N','D','R','E','W'};
        for (char i : arr){
            System.out.print(i);
        }System.out.println();
    }
}