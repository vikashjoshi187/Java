class Prog2b {
    public static void main(String[] args) {
        char arr[] = { 'H','E','L','L','O',' ','A','N','D','R','E','W'};
        for (int i = 0; i < arr.length; i++){
            System.out.print(arr[i]);
        }System.out.println();
    }
}