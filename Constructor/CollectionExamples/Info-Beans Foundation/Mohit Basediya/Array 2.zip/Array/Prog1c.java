class Prog1c {
    public static void main(String[] args) {
        int arr[] = { 91, 92, 95, 97, 90 };
        System.out.println("Marks Of 5 Subjects Are -> ");
        int i = 0;
        while (i < 5) {
            System.out.print("arr["+i+"] -> ");
            System.out.println(arr[i]);
            i++;
        }
    }
}