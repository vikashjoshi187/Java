import java.util.Scanner;
class Prog16{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size Of Array -> ");
        int size = sc.nextInt();
        int arr[] = new int[size];
        System.out.println("Enter Elements -> \n");
        for (int i = 0; i < size; i++) {
            System.out.println("Element -> " + i + "->");
            arr[i] = sc.nextInt();
        }
        System.out.println("Original Array -> ");
        for (int i = 0; i < size; i++){
            System.out.print(arr[i]+"\t");
            }
        for (int i = 0; i < size/2; i++){
            int temp = arr[i];
            arr[i] = arr[size-1-i];
            arr[size-1-i] = temp;
        }
        System.out.println("\nReverse Array -> ");
        for (int i = 0; i < size; i++){
        System.out.print(arr[i]+"\t");
        }System.out.println();
    }
}