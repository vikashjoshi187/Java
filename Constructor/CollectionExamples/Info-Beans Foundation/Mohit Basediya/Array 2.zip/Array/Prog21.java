import java.util.Scanner;
class Prog21 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Size Of Array -> ");
        int size = sc.nextInt();
        int arr[] = new int[size];
        System.out.println("Enter Elements -> \n");
        for (int i = 0; i < size; i++) {
            System.out.println("Element -> " + i + "->");
            arr[i] = sc.nextInt();
        }
        System.out.println("Given Array Is -> ");
        for (int i = 0; i < size; i++) {
            System.out.print(arr[i] + "\t");
        }
        int i;
        for (i = 0; i < size / 2; i++) {
            if (arr[i] != arr[size - 1 - i]) {
                break;
            }
        }
        if (i >= size / 2) {
            System.out.println("\nArray is Palindrome");
        } else {
            System.out.println("\nArray Is Not Palindrome");
        }
    }
}