class Prog2 {
    public static void main(String[] args) {
        char arr[] = { 'H','E','L','L','O',' ','A','N','D','R','E','W'};
        System.out.print(arr[0]);
        System.out.print(arr[1]);
        System.out.print(arr[2]);
        System.out.print(arr[3]);
        System.out.print(arr[4]);
        System.out.print(arr[5]);
        System.out.print(arr[6]);
        System.out.print(arr[7]);
        System.out.print(arr[8]);
        System.out.print(arr[9]);
        System.out.print(arr[10]);
        System.out.print(arr[11]);
        System.out.println();
    }
}