class Prog1b {
    public static void main(String[] args) {
        int arr[] = { 91, 92, 95, 97, 90 };
        System.out.println("Marks Of 5 Subjects Are -> ");
        for (int i = 0; i < 5; i++) {
            System.out.print("arr["+i+"] -> ");
            System.out.println(arr[i]);
        }
    }
}