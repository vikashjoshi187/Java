class Prac2 {
    public static void main(String[] args) {
        int arr[] = {1,2,3,4,5};
        System.out.println("Array Elements Are : ");
        for (int i = 0; i < arr.length; i++){
            System.out.print("\t"+arr[i]);
        }System.out.println();
    }
}