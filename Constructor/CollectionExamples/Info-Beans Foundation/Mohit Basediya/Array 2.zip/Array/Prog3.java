import java.util.Scanner;
class Prog3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int arr[] = new int[7];
        System.out.println("Enter Marks of Subjects -> \n");
        for (int i = 0; i < arr.length; i++) {
            System.out.println("Marks Of " + i + " Subject -> ");
            arr[i] = sc.nextInt();
        }
        System.out.println("\n\nMarks Of Subjects Are -> \n");
        for (int i = 0; i < arr.length; i++) {
            System.out.println("arr[" + i + "] -> " + arr[i]);
        }
    }
}